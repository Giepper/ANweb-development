CORPORATE GOTHIC NBP
made by Nate Halley
using FontStruct
Version 1.2
Date: 21 September 2012

DESCRIPTION
===========
A thin, pretentious typeface. Perfect for corporate logotyping.

CHANGES IN VERSION 1.2
======================
-Fixed spacing (kerning isn't perfect but neither is Fonstruct :P)
-Redesigned lowercase "a" to double-storey
-Fixed uppercase "P"
-Fixed baseline issue with lowercase g, p, and q

LICENSE
=======
Corporate Gothic is Creative Commons (by-sa) Attribution Share Alike. That means it's free to download and use. You can also upload it to another website but only as long as you give me credit for making it. You can even make changes to it as long as you give me credit for making the first version and license your changes under CC-BY-SA too.
For more information, go to:
http://creativecommons.org/licenses/by-sa/3.0/

A REQUEST FROM NATE547
======================
Once you install this font, find 2 ways to make the world, the country, your home state/province/county, or your hometown better than it is. Even if it's just recycling your newspaper instead of tossing it on the rubbish.

If you're upgrading from a previous version to 1.2, find two ways you contribute to global de-evolution (like not using your freedom of choice or giving authority to someone unworthy of it) and take immediate action to change it!
Of course, you're not obligated by law to do either of these things.... it's just a request from a Sensible Human who wants our world to change.

Duty now for the future.

Nate547 (Total FontGeek)